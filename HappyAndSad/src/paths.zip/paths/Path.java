package paths;

public abstract class Path {
	
	public abstract void path();
	
}
